#ifndef __1986ve9x_H
#define __1986ve9x_H

#include "common.h"
#include "1986ve9x_gpio.h"
#include "1986ve9x_clk.h"
#include "1986ve9x_tim.h"
#include "1986ve9x_irq.h"
#include "1986ve9x_i2c.h"
#include "1986ve9x_ssp.h"
#include "1986ve9x_uart.h"
#include "1986ve9x_ext.h"
#include "1986ve9x_dma.h"
#include "1986ve9x_adc.h"
#include "1986ve9x_dac.h"

#endif
