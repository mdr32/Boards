#ifndef __CLK_H__
#define __CLK_H__

#include "type_custom.h"

void clk_CoreConfig(void);

#endif

