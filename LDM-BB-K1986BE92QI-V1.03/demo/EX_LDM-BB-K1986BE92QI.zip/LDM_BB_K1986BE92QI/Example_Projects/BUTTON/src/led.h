#ifndef __LED_H__
#define __LED_H__

#include "type_custom.h"

void led_Init(void);
void led_Write(bool on_off);

#endif
